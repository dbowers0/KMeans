package clusteringk;

import java.util.ArrayList;

public class Centroid {

	private ArrayList<Double> centroidPoint;

	public ArrayList<Double> getCentroidPoint() {
		return centroidPoint;
	}

	public void setCentroidPoint(ArrayList<Double> centroidPoint) {
		this.centroidPoint = centroidPoint;
	}
}
